using UnityEngine;
using UnityEngine.UI;

public class RunnerHUD : MonoBehaviour
{
    public Transform player;
    Text scoreText, chocolateText, soulsText, bestText, titleText, messageText;
    GameObject menuPanel, gameOverPanel, pausePanel;
    RunnerController controller;

    void Start()
    {
        controller = player.GetComponent<RunnerController>();
        MakeBackground();
        MakeTopBar();
        MakeMenu();
        MakeGameOver();
        MakePause();
        MakeControls();
    }

    void Update()
    {
        scoreText.text = $"POÄNG  {RunnerGameDirector.Score}";
        chocolateText.text = $"KEX  {RunnerGameDirector.Chocolate}";
        soulsText.text = $"SJÄLAR  {CurrencyWallet.Instance?.Souls ?? 0}";
        bestText.text = $"BÄST  {RunnerGameDirector.BestScore}";
        menuPanel.SetActive(RunnerGameDirector.State == RunnerGameDirector.RunState.Menu);
        gameOverPanel.SetActive(RunnerGameDirector.GameOver);
        pausePanel.SetActive(RunnerGameDirector.State == RunnerGameDirector.RunState.Paused);
    }

    void MakeBackground()
    {
        var bg = new GameObject("NightBackdrop"); bg.transform.SetParent(transform, false);
        var rt = bg.AddComponent<RectTransform>(); rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = rt.offsetMax = Vector2.zero;
        var img = bg.AddComponent<Image>(); img.color = new Color(0.015f, 0.02f, 0.06f, 0.92f);
        bg.transform.SetAsFirstSibling();
    }

    void MakeTopBar()
    {
        scoreText = MakeText("Score", "POÄNG  0", new Vector2(28,-28), 34, new Vector2(0,1), new Vector2(0,1));
        chocolateText = MakeText("Chocolate", "KEX  0", new Vector2(28,-72), 24, new Vector2(0,1), new Vector2(0,1));
        soulsText = MakeText("Souls", "SJÄLAR  0", new Vector2(-28,-28), 25, new Vector2(1,1), new Vector2(1,1));
        bestText = MakeText("Best", "BÄST  0", new Vector2(-28,-62), 20, new Vector2(1,1), new Vector2(1,1));
        var pause = MakeButton("Ⅱ", new Vector2(-32,-108), new Vector2(1,1), new Vector2(70,55)); pause.onClick.AddListener(RunnerGameDirector.PauseRun);
    }

    void MakeMenu()
    {
        menuPanel = Panel("MainMenu", new Vector2(0.08f,0.18f), new Vector2(0.92f,0.82f), new Color(0.02f,0.025f,0.07f,0.96f));
        titleText = MakeChildText(menuPanel, "Title", "LUCIFER\nNATTFÄRDEN", 58, TextAnchor.MiddleCenter, new Vector2(0,0.58f), new Vector2(1,0.92f));
        MakeChildText(menuPanel, "Sub", "Spring genom natten. Undvik mörkret. Samla Kex.", 22, TextAnchor.MiddleCenter, new Vector2(0.08f,0.43f), new Vector2(0.92f,0.58f));
        var play = MakeChildButton(menuPanel, "SPRING", new Vector2(0.18f,0.16f), new Vector2(0.82f,0.34f)); play.onClick.AddListener(Start);
        MakeChildText(menuPanel, "Tip", "SWIPE  •  VÄNSTER/HÖGER = BYT FIL\nUPP = HOPPA   NER = GLID", 18, TextAnchor.MiddleCenter, new Vector2(0.08f,0.03f), new Vector2(0.92f,0.15f));
    }

    void MakeGameOver()
    {
        gameOverPanel = Panel("GameOver", new Vector2(0.08f,0.22f), new Vector2(0.92f,0.78f), new Color(0.02f,0.01f,0.04f,0.97f));
        messageText = MakeChildText(gameOverPanel, "Message", "FÅNGAD", 52, TextAnchor.MiddleCenter, new Vector2(0,0.56f), new Vector2(1,0.9f));
        MakeChildText(gameOverPanel, "Stats", "", 25, TextAnchor.MiddleCenter, new Vector2(0.08f,0.38f), new Vector2(0.92f,0.57f));
        var retry = MakeChildButton(gameOverPanel, "FÖRSÖK IGEN", new Vector2(0.12f,0.12f), new Vector2(0.88f,0.3f)); retry.onClick.AddListener(RunnerGameDirector.Restart);
    }

    void MakePause()
    {
        pausePanel = Panel("Pause", new Vector2(0.15f,0.3f), new Vector2(0.85f,0.7f), new Color(0.02f,0.025f,0.07f,0.97f));
        MakeChildText(pausePanel,"PauseText","PAUS",48,TextAnchor.MiddleCenter,new Vector2(0,0.55f),new Vector2(1,0.88f));
        var resume = MakeChildButton(pausePanel,"FORTSÄTT",new Vector2(0.15f,0.14f),new Vector2(0.85f,0.36f)); resume.onClick.AddListener(RunnerGameDirector.ResumeRun);
    }

    void MakeControls()
    {
        var left = MakeButton("‹", new Vector2(80,55), new Vector2(0,0), new Vector2(105,90)); left.onClick.AddListener(controller.MoveLeft);
        var right = MakeButton("›", new Vector2(-80,55), new Vector2(1,0), new Vector2(105,90)); right.onClick.AddListener(controller.MoveRight);
        var jump = MakeButton("↑", new Vector2(0,58), new Vector2(0.5f,0), new Vector2(105,90)); jump.onClick.AddListener(controller.JumpButton);
        var slide = MakeButton("↓", new Vector2(0,155), new Vector2(0.5f,0), new Vector2(105,90)); slide.onClick.AddListener(controller.SlideButton);
    }

    void Start() => FindFirstObjectByType<RunnerGameDirector>().StartRun(player);

    GameObject Panel(string name, Vector2 min, Vector2 max, Color color)
    {
        var go = new GameObject(name); go.transform.SetParent(transform,false); var rt=go.AddComponent<RectTransform>(); rt.anchorMin=min;rt.anchorMax=max;rt.offsetMin=rt.offsetMax=Vector2.zero; var img=go.AddComponent<Image>();img.color=color;return go;
    }
    Text MakeText(string name,string value,int size,Vector2 pos,int unused=0){return MakeText(name,value,pos,size,new Vector2(0,1),new Vector2(0,1));}
    Text MakeText(string name,string value,Vector2 pos,int size,Vector2 anchor,Vector2 pivot)
    {
        var go=new GameObject(name);go.transform.SetParent(transform,false);var rt=go.AddComponent<RectTransform>();rt.anchorMin=anchor;rt.anchorMax=anchor;rt.pivot=pivot;rt.anchoredPosition=pos;rt.sizeDelta=new Vector2(700,70);var t=go.AddComponent<Text>();t.font=Resources.GetBuiltinResource<Font>("Arial.ttf");t.fontSize=size;t.fontStyle=FontStyle.Bold;t.color=Color.white;t.text=value;t.raycastTarget=false;return t;
    }
    Text MakeChildText(GameObject parent,string name,string value,int size,TextAnchor align,Vector2 min,Vector2 max){var go=new GameObject(name);go.transform.SetParent(parent.transform,false);var rt=go.AddComponent<RectTransform>();rt.anchorMin=min;rt.anchorMax=max;rt.offsetMin=rt.offsetMax=Vector2.zero;var t=go.AddComponent<Text>();t.font=Resources.GetBuiltinResource<Font>("Arial.ttf");t.fontSize=size;t.fontStyle=FontStyle.Bold;t.alignment=align;t.color=Color.white;t.text=value;return t;}
    Button MakeButton(string label,Vector2 pos,Vector2 anchor,Vector2 size){var go=new GameObject(label+"Button");go.transform.SetParent(transform,false);var rt=go.AddComponent<RectTransform>();rt.anchorMin=anchor;rt.anchorMax=anchor;rt.pivot=anchor;rt.anchoredPosition=pos;rt.sizeDelta=size;var img=go.AddComponent<Image>();img.color=new Color(0.12f,0.08f,0.2f,0.9f);var b=go.AddComponent<Button>();var t=MakeChildText(go,"Text",label,34,TextAnchor.MiddleCenter,Vector2.zero,Vector2.one);return b;}
    Button MakeChildButton(GameObject parent,string label,Vector2 min,Vector2 max){var go=new GameObject(label+"Button");go.transform.SetParent(parent.transform,false);var rt=go.AddComponent<RectTransform>();rt.anchorMin=min;rt.anchorMax=max;rt.offsetMin=rt.offsetMax=Vector2.zero;var img=go.AddComponent<Image>();img.color=new Color(0.3f,0.06f,0.22f,1f);var b=go.AddComponent<Button>();MakeChildText(go,"Text",label,30,TextAnchor.MiddleCenter,Vector2.zero,Vector2.one);return b;}
}
