# Förslag på svensk butikstext

## Appnamn
Lucifer: Nattfärden

## Kort beskrivning
Spring genom nattstaden, undvik korpar och hinder och samla Kexchoklad i en mörk endless runner.

## Lång beskrivning
Natten har blivit farligare.

Spring genom en regnig neonstad, byt körfält, hoppa, glid och undvik hinder medan jakten fortsätter. Samla föremål, bygg din high score och lås upp nya looks.

**Funktioner**
- Endless runner med 3 körfält
- Mörk svensk nattstad
- Korpar, hinder och oväntade överraskningar
- Fasta skins och hjälpobjekt
- In-game-valuta som även kan tjänas genom gameplay
- Regelbundna nya banor och kosmetiska föremål i framtida uppdateringar

Vissa digitala föremål kan köpas separat i appen. Köp är frivilliga.

## Viktigt
Använd endast grafik, musik, varumärken och namn som ni har rätt att använda. Byt ut platshållartext och produktpriser innan publicering.
