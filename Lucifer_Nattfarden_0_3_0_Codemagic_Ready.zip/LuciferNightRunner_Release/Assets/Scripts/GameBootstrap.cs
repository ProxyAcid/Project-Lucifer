using UnityEngine;

public class GameBootstrap : MonoBehaviour
{
    void Awake()
    {
        Application.targetFrameRate = 60;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        if (FindFirstObjectByType<RunnerController>() != null) return;

        var player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Lucifer_Player";
        player.transform.position = new Vector3(0, 1.2f, -3f);
        player.transform.localScale = new Vector3(0.8f, 1.2f, 0.8f);
        var playerRenderer = player.GetComponent<Renderer>();
        var playerMat = new Material(Shader.Find("Standard")); playerMat.color = new Color(0.12f,0.08f,0.18f); playerRenderer.material = playerMat;
        var runner = player.AddComponent<RunnerController>(); runner.forwardSpeed = 11f;

        var cameraObj = new GameObject("Main Camera"); cameraObj.tag = "MainCamera";
        var cam = cameraObj.AddComponent<Camera>(); cam.fieldOfView = 62f; cameraObj.transform.position = new Vector3(0,4.4f,-9f);
        var follow = cameraObj.AddComponent<RunnerCamera>(); follow.target = player.transform;

        var director = new GameObject("GameDirector");
        var gameDirector = director.AddComponent<RunnerGameDirector>(); gameDirector.LoadBest();

        var economy = new GameObject("Economy"); economy.AddComponent<CurrencyWallet>(); economy.AddComponent<OwnedSkins>(); economy.AddComponent<IAPManager>();

        var canvasObj = new GameObject("HUD"); var canvas=canvasObj.AddComponent<Canvas>(); canvas.renderMode=RenderMode.ScreenSpaceOverlay;
        var scaler=canvasObj.AddComponent<UnityEngine.UI.CanvasScaler>(); scaler.uiScaleMode=UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize; scaler.referenceResolution=new Vector2(1170,2532); scaler.matchWidthOrHeight=0.5f;
        canvasObj.AddComponent<UnityEngine.UI.GraphicRaycaster>(); var hud=canvasObj.AddComponent<RunnerHUD>(); hud.player=player.transform;
        if (FindFirstObjectByType<UnityEngine.EventSystems.EventSystem>() == null) { var es=new GameObject("EventSystem"); es.AddComponent<UnityEngine.EventSystems.EventSystem>(); es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>(); }

        var lightObj=new GameObject("MoonLight");var light=lightObj.AddComponent<Light>();light.type=LightType.Directional;light.intensity=0.55f;light.transform.rotation=Quaternion.Euler(35f,-25f,0f);
        RenderSettings.ambientIntensity=0.22f; RenderSettings.fog=true; RenderSettings.fogDensity=0.014f; RenderSettings.fogColor=new Color(0.01f,0.015f,0.045f);
    }
}
