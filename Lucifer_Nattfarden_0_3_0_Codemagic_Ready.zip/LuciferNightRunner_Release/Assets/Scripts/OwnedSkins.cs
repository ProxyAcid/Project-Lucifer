using UnityEngine;
using System.Collections.Generic;

public class OwnedSkins : MonoBehaviour
{
    public static OwnedSkins Instance { get; private set; }
    const string Prefix = "skin_owned_";

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public bool Has(string skinId) => PlayerPrefs.GetInt(Prefix + skinId, 0) == 1;

    public void Unlock(string skinId)
    {
        PlayerPrefs.SetInt(Prefix + skinId, 1);
        PlayerPrefs.Save();
    }
}
