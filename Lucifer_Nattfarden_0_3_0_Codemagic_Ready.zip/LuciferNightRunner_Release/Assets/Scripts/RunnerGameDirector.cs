using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RunnerGameDirector : MonoBehaviour
{
    public enum RunState { Menu, Running, GameOver, Paused }
    public static RunState State { get; private set; } = RunState.Menu;
    public static bool GameOver => State == RunState.GameOver;
    public static bool IsRunning => State == RunState.Running;
    public static int Score { get; private set; }
    public static int Chocolate { get; private set; }
    public static int SoulsEarned { get; private set; }
    public static int BestScore { get; private set; }

    [SerializeField] float firstSpawnZ = 18f;
    [SerializeField] float spawnAhead = 110f;
    [SerializeField] float despawnBehind = 35f;
    [SerializeField] float minGap = 9f;
    [SerializeField] float maxGap = 14f;

    Transform player;
    float nextSpawnZ;
    float runStartZ;
    readonly List<GameObject> spawned = new();

    public void StartRun(Transform target)
    {
        player = target;
        ClearWorld();
        Score = 0;
        Chocolate = 0;
        SoulsEarned = 0;
        nextSpawnZ = firstSpawnZ;
        runStartZ = target.position.z;
        State = RunState.Running;
        Time.timeScale = 1f;
        for (int i = 0; i < 14; i++) SpawnSegment();
    }

    void Update()
    {
        if (player == null || !IsRunning) return;

        int distanceScore = Mathf.FloorToInt(Mathf.Max(0f, player.position.z - runStartZ) * 2f);
        Score = Mathf.Max(Score, distanceScore + Chocolate * 25);
        while (nextSpawnZ < player.position.z + spawnAhead) SpawnSegment();

        for (int i = spawned.Count - 1; i >= 0; i--)
        {
            var item = spawned[i];
            if (!item) { spawned.RemoveAt(i); continue; }
            if (item.transform.position.z < player.position.z - despawnBehind)
            {
                Destroy(item);
                spawned.RemoveAt(i);
            }
        }
    }

    void SpawnSegment()
    {
        float z = nextSpawnZ;
        nextSpawnZ += Random.Range(minGap, maxGap);
        int safeLane = Random.Range(-1, 2);
        int blockedCount = Random.value < Mathf.Clamp01(0.18f + Score / 18000f) ? 2 : 1;

        var lanes = new List<int> { -1, 0, 1 };
        lanes.Remove(safeLane);
        if (blockedCount == 1) lanes.RemoveAt(Random.Range(0, lanes.Count));

        foreach (int lane in lanes)
        {
            if (Random.value < 0.78f) SpawnObstacle(lane, z);
        }
        if (Random.value < 0.9f) SpawnChocolate(safeLane, z + Random.Range(-1f, 1f));

        if (segmentCount % 7 == 0 && Random.value < 0.55f) SpawnBoost(safeLane, z + 2f);
        SpawnGround(z);
        segmentCount++;
    }

    int segmentCount;

    void SpawnGround(float z)
    {
        var ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "WetStreet";
        ground.transform.position = new Vector3(0f, -0.45f, z);
        ground.transform.localScale = new Vector3(9f, 0.5f, maxGap + 1.2f);
        ApplyMat(ground, new Color(0.025f, 0.035f, 0.065f));
        spawned.Add(ground);
    }

    void SpawnObstacle(int lane, float z)
    {
        var obstacle = GameObject.CreatePrimitive(PrimitiveType.Cube);
        obstacle.name = "NightObstacle";
        obstacle.transform.position = new Vector3(lane * 2.4f, 1f, z);
        obstacle.transform.localScale = new Vector3(1.75f, 2f, 1.2f);
        ApplyMat(obstacle, new Color(0.18f, 0.02f, 0.12f));
        obstacle.AddComponent<RunnerObstacle>();
        spawned.Add(obstacle);
    }

    void SpawnChocolate(int lane, float z)
    {
        var pickup = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        pickup.name = "KexChoklad";
        pickup.transform.position = new Vector3(lane * 2.4f, 1.15f, z);
        pickup.transform.localScale = new Vector3(0.42f, 0.12f, 0.42f);
        pickup.transform.Rotate(90f, 0f, 0f);
        ApplyMat(pickup, new Color(0.95f, 0.55f, 0.12f));
        pickup.AddComponent<ChocolatePickup>();
        spawned.Add(pickup);
    }

    void SpawnBoost(int lane, float z)
    {
        var pickup = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        pickup.name = "SoulBoost";
        pickup.transform.position = new Vector3(lane * 2.4f, 1.2f, z);
        pickup.transform.localScale = Vector3.one * 0.45f;
        ApplyMat(pickup, new Color(0.25f, 0.75f, 1f));
        pickup.AddComponent<BoostPickup>();
        spawned.Add(pickup);
    }

    static void ApplyMat(GameObject go, Color color)
    {
        var r = go.GetComponent<Renderer>();
        if (r == null) return;
        var m = new Material(Shader.Find("Standard"));
        m.color = color;
        r.material = m;
    }

    public static void CollectChocolate()
    {
        Chocolate++;
        Score += 25;
        SoulsEarned += 5;
        CurrencyWallet.Instance?.AddSouls(5);
    }

    public static void CollectBoost()
    {
        CurrencyWallet.Instance?.AddBoosts(1);
        SoulsEarned += 10;
        Score += 50;
    }

    public static void EndRun()
    {
        if (GameOver || State == RunState.Menu) return;
        State = RunState.GameOver;
        BestScore = Mathf.Max(BestScore, Score);
        PlayerPrefs.SetInt("lucifer_best_score", BestScore);
        PlayerPrefs.Save();
    }

    public static void PauseRun()
    {
        if (!IsRunning) return;
        State = RunState.Paused;
        Time.timeScale = 0f;
    }

    public static void ResumeRun()
    {
        if (State != RunState.Paused) return;
        State = RunState.Running;
        Time.timeScale = 1f;
    }

    public static void Restart()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public static bool TryRevive()
    {
        if (State != RunState.GameOver || CurrencyWallet.Instance == null || !CurrencyWallet.Instance.TryUseRevive()) return false;
        State = RunState.Running;
        Time.timeScale = 1f;
        Score += 100;
        return true;
    }

    public void LoadBest()
    {
        BestScore = PlayerPrefs.GetInt("lucifer_best_score", 0);
    }

    void ClearWorld()
    {
        foreach (var item in spawned) if (item) Destroy(item);
        spawned.Clear();
        segmentCount = 0;
    }

    void OnDestroy() { Time.timeScale = 1f; }
}

public sealed class RunnerObstacle : MonoBehaviour { }

public sealed class ChocolatePickup : MonoBehaviour
{
    void Awake() { GetComponent<Collider>().isTrigger = true; }
    void Update() { transform.Rotate(0f, 180f * Time.deltaTime, 0f, Space.World); }
    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<RunnerController>() == null) return;
        RunnerGameDirector.CollectChocolate();
        Destroy(gameObject);
    }
}

public sealed class BoostPickup : MonoBehaviour
{
    void Awake() { GetComponent<Collider>().isTrigger = true; }
    void Update() { transform.Rotate(90f * Time.deltaTime, 150f * Time.deltaTime, 0f, Space.World); }
    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<RunnerController>() == null) return;
        RunnerGameDirector.CollectBoost();
        Destroy(gameObject);
    }
}
