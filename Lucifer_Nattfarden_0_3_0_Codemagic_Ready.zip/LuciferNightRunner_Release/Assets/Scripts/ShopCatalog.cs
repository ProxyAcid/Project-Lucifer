using UnityEngine;

[System.Serializable]
public class ShopItem
{
    public string id;
    public string displayName;
    public int soulsPrice;
    public string description;
}

public class ShopCatalog : MonoBehaviour
{
    public ShopItem[] fixedItems =
    {
        new ShopItem { id="skin_shadow", displayName="Shadow", soulsPrice=750, description="Mörk nattlook." },
        new ShopItem { id="skin_blue_angel", displayName="Blue Angel", soulsPrice=1250, description="Elektriskt blå look." },
        new ShopItem { id="revive", displayName="Extra liv", soulsPrice=250, description="Ger ett extra försök." },
        new ShopItem { id="boost", displayName="3x Boost", soulsPrice=400, description="Tre hastighetsboostar." }
    };

    public bool BuyWithSouls(ShopItem item)
    {
        if (!CurrencyWallet.Instance.SpendSouls(item.soulsPrice))
            return false;

        if (item.id == "revive") CurrencyWallet.Instance.AddRevives(1);
        if (item.id == "boost") CurrencyWallet.Instance.AddBoosts(3);
        if (item.id.StartsWith("skin_"))
            OwnedSkins.Instance.Unlock(item.id);

        return true;
    }
}
