public static class IAPProductIds
{
    // Consumables
    public const string Coins100 = "lucifer_coins_100";
    public const string Coins550 = "lucifer_coins_550";
    public const string Coins1200 = "lucifer_coins_1200";
    public const string Revive1 = "lucifer_revive_1";
    public const string Boost3 = "lucifer_boost_3";

    // Non-consumables
    public const string SkinNightRunner = "skin_night_runner";
    public const string SkinRaven = "skin_raven";
}
