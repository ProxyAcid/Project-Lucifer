# Lucifer: Nattfärden — testa på din iPhone

## Om du har Mac
1. Installera Unity 6 och kontrollera att **iOS Build Support** är installerat.
2. Öppna projektet i Unity Hub.
3. File → Build Profiles/Build Settings → välj iOS och byt plattform.
4. Ange ett unikt Bundle Identifier under Player Settings, t.ex. `se.dittnamn.lucifer.nattfarden`.
5. Klicka **Build and Run**. Unity skapar ett Xcode-projekt och Xcode bygger/installlerar appen på den anslutna iPhonen.
6. Anslut iPhonen med kabel och tryck Trust om iPhone frågar.
7. Lägg till ditt Apple Account i Xcode → Settings/Accounts.
8. Välj appens target → Signing & Capabilities → välj ditt Team och slå på Automatically manage signing.
9. Välj iPhonen som Run Destination och tryck ▶.
10. På iPhonen: Settings → Privacy & Security → Developer Mode → On, om iOS frågar.

### Gratis Apple Account
För personlig testning kan ett vanligt Apple Account användas. Xcode skapar en Personal Team-signering. Apple anger att sådana testinstallationer behöver omprovisioneras efter 7 dagar.

### Ingen Mac?
Unity kan generera Xcode-projekt på andra operativsystem, men själva lokala iOS-builden kräver macOS/Xcode. Alternativet är en molnbaserad Unity-buildtjänst som genererar iOS-builden åt dig.

## Innan App Store
- Byt Bundle ID till ditt riktiga.
- Lägg till App Icon och launch assets.
- Lägg in riktig grafik/ljud.
- Lägg till Unity IAP 5.x och konfigurera produkt-ID:n i App Store Connect.
- Testa köp via sandbox/TestFlight.
- Testa på flera riktiga iPhone-modeller.
- Skapa archive i Xcode och ladda upp till App Store Connect/TestFlight.
