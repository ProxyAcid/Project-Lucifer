public static class ReleaseConfig
{
    public const string AppName = "Lucifer: Nattfärden";
    public const string Version = "0.3.0";
    public const string AppleBundleId = "se.yourstudio.lucifer.nattfarden";
    public const string AndroidApplicationId = "se.yourstudio.lucifer.nattfarden";
}
