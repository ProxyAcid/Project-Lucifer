using UnityEngine;

// Store integration is intentionally optional in the playable build. Add Unity IAP 5.x
// and replace the methods below with live StoreController calls before App Store submission.
public class IAPManager : MonoBehaviour
{
    public static IAPManager Instance { get; private set; }
    public bool IsReady { get; private set; }
    void Awake(){ if(Instance!=null&&Instance!=this){Destroy(gameObject);return;} Instance=this; DontDestroyOnLoad(gameObject); }
    void Start(){ IsReady=false; }
    public void Buy(string productId){ Debug.Log("IAP placeholder: configure Unity IAP and App Store Connect product " + productId); }
}
