using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class BuildScript
{
    public static void BuildIos()
    {
        var output = Path.Combine(Directory.GetCurrentDirectory(), "ios");
        Directory.CreateDirectory(output);

        PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.iOS, "se.lucifer.nattfarden");
        PlayerSettings.productName = "Lucifer: Nattfärden";
        PlayerSettings.companyName = "Lucifer Nattfärden";
        PlayerSettings.bundleVersion = "0.3.0";
        PlayerSettings.iOS.buildNumber = "1";

        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.iOS, BuildTarget.iOS);

        var scenes = new[] { "Assets/Scenes/Main.unity" };
        var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions {
            scenes = scenes,
            locationPathName = output,
            target = BuildTarget.iOS,
            options = BuildOptions.None
        });

        if (report.summary.result != BuildResult.Succeeded)
            throw new System.Exception("iOS build failed: " + report.summary.result);
    }
}
