using UnityEngine;

public class RunnerCamera : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = new Vector3(0, 4.2f, -9f);

    void LateUpdate()
    {
        if (!target) return;
        Vector3 desired = target.position + offset;
        transform.position = Vector3.Lerp(transform.position, desired, 8f * Time.deltaTime);
        transform.LookAt(target.position + Vector3.up * 1.1f);
    }
}
