# Codemagic – Lucifer: Nattfärden

Det här projektet är förberett för Codemagic.

## Viktigt
- Bundle ID: `se.lucifer.nattfarden`
- Unity: `6000.0.37f1`
- Development-workflow: för test på registrerad iPhone
- App Store-workflow: för TestFlight/App Store

## Första gången
1. Lägg projektet i ett GitHub-repository.
2. Skapa konto på Codemagic och lägg till repositoryt.
3. Lägg till Unity-credentials som environment group `unity_credentials`:
   `UNITY_EMAIL`, `UNITY_SERIAL`, `UNITY_PASSWORD`.
4. I Apple Developer/App Store Connect skapar du App ID `se.lucifer.nattfarden`.
5. Lägg in Apple-signering i Codemagic. För development behöver din iPhone vara registrerad i Apple Developer och provisioning-profilen måste innehålla enheten.
6. Kör workflow `ios-development`.
7. Ladda ner IPA-artifakten från Codemagic.

För TestFlight kör `ios-app-store` efter att appen finns som app-record i App Store Connect.

Använd aldrig Apple-lösenord, API-nycklar eller certifikat i projektfiler eller chatten.
