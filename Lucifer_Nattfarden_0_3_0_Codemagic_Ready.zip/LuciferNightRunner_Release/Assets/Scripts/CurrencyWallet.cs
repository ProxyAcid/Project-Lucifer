using UnityEngine;

public class CurrencyWallet : MonoBehaviour
{
    public static CurrencyWallet Instance { get; private set; }

    const string SoulsKey = "lucifer_souls";
    const string RevivesKey = "lucifer_revives";
    const string BoostsKey = "lucifer_boosts";

    public int Souls => Mathf.Max(0, PlayerPrefs.GetInt(SoulsKey, 0));
    public int Revives => Mathf.Max(0, PlayerPrefs.GetInt(RevivesKey, 0));
    public int Boosts => Mathf.Max(0, PlayerPrefs.GetInt(BoostsKey, 0));

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void AddSouls(int amount)
    {
        if (amount <= 0) return;
        Set(SoulsKey, Souls + amount);
    }

    public bool SpendSouls(int amount)
    {
        if (amount <= 0 || Souls < amount) return false;
        Set(SoulsKey, Souls - amount);
        return true;
    }

    public void AddRevives(int amount)
    {
        if (amount <= 0) return;
        Set(RevivesKey, Revives + amount);
    }

    public bool TryUseRevive()
    {
        if (Revives <= 0) return false;
        Set(RevivesKey, Revives - 1);
        return true;
    }

    public void AddBoosts(int amount)
    {
        if (amount <= 0) return;
        Set(BoostsKey, Boosts + amount);
    }

    public bool TryUseBoost()
    {
        if (Boosts <= 0) return false;
        Set(BoostsKey, Boosts - 1);
        return true;
    }

    static void Set(string key, int value)
    {
        PlayerPrefs.SetInt(key, Mathf.Max(0, value));
        PlayerPrefs.Save();
    }
}
