Install Unity In-App Purchasing (com.unity.purchasing) from Window > Package Manager > Unity Registry.
Use the current Unity IAP 5.x version compatible with your Unity editor.
