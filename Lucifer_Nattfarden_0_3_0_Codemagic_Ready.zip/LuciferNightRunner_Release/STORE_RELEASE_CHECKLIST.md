# Store release checklist

## Apple App Store
[ ] Adult/organization responsible for Apple Developer account and agreements
[ ] Bundle ID set
[ ] Signing + provisioning configured
[ ] App icon and screenshots
[ ] Age rating questionnaire
[ ] Privacy policy URL
[ ] App privacy answers
[ ] IAP products created with the exact IDs in IAPProductIds.cs
[ ] IAP prices and localized names/descriptions
[ ] TestFlight internal/external testing
[ ] App Review notes explain IAP test path
[ ] Final archive uploaded

## Google Play
[ ] Adult/organization responsible for Play Console account and agreements
[ ] Application ID set
[ ] Upload key / Play App Signing
[ ] Current required target API
[ ] Store listing
[ ] App icon + screenshots
[ ] Content rating
[ ] Target audience
[ ] Data Safety form
[ ] Privacy policy URL
[ ] Billing products created with exact IDs
[ ] Closed testing track
[ ] Production AAB

## Monetization rules implemented
- Fixed-price products
- No loot boxes
- Virtual currency is only usable in this game
- Prices are supplied by the platform store
- Purchases are not required to play
- Restore/re-fetch path exists for non-consumables
- Production should add server-side purchase validation
