using System.Collections;
using UnityEngine;

public class RunnerController : MonoBehaviour
{
    [SerializeField] public float forwardSpeed = 11f;
    [SerializeField] float laneWidth = 2.4f;
    [SerializeField] float laneChangeSpeed = 18f;
    [SerializeField] float jumpForce = 8.2f;
    [SerializeField] float gravity = -24f;
    [SerializeField] float swipeThreshold = 45f;

    int lane;
    float verticalVelocity;
    CharacterController cc;
    Vector2 touchStart;
    bool sliding;
    float boostTimer;

    public bool IsSliding => sliding;

    void Awake()
    {
        cc = GetComponent<CharacterController>() ?? gameObject.AddComponent<CharacterController>();
        var capsule = GetComponent<CapsuleCollider>();
        if (capsule) Destroy(capsule);
        cc.center = new Vector3(0, 0, 0);
        cc.height = 2.4f;
        cc.radius = 0.45f;
        cc.stepOffset = 0.25f;
        cc.skinWidth = 0.03f;
    }

    void Update()
    {
        if (!RunnerGameDirector.IsRunning) return;
        HandleInput();
        float speed = forwardSpeed + (boostTimer > 0f ? 4f : 0f);
        boostTimer = Mathf.Max(0f, boostTimer - Time.deltaTime);
        float targetX = lane * laneWidth;
        float nextX = Mathf.MoveTowards(transform.position.x, targetX, laneChangeSpeed * Time.deltaTime);
        float dx = nextX - transform.position.x;
        if (cc.isGrounded && verticalVelocity < 0f) verticalVelocity = -2f;
        verticalVelocity += gravity * Time.deltaTime;
        cc.Move(new Vector3(dx, verticalVelocity, speed) * Time.deltaTime);
        if (transform.position.y < -3f) RunnerGameDirector.EndRun();
    }

    public void ActivateBoost(float duration = 3f) => boostTimer = Mathf.Max(boostTimer, duration);

    void HandleInput()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow)) MoveLane(-1);
        if (Input.GetKeyDown(KeyCode.RightArrow)) MoveLane(1);
        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.Space)) Jump();
        if (Input.GetKeyDown(KeyCode.DownArrow)) Slide();
        if (Input.touchCount == 0) return;
        Touch touch = Input.GetTouch(0);
        if (touch.phase == TouchPhase.Began) { touchStart = touch.position; return; }
        if (touch.phase != TouchPhase.Ended) return;
        Vector2 delta = touch.position - touchStart;
        if (delta.magnitude < swipeThreshold) return;
        if (Mathf.Abs(delta.x) > Mathf.Abs(delta.y)) MoveLane(delta.x > 0f ? 1 : -1);
        else if (delta.y > 0f) Jump(); else Slide();
    }

    public void MoveLeft() => MoveLane(-1);
    public void MoveRight() => MoveLane(1);
    public void JumpButton() => Jump();
    public void SlideButton() => Slide();
    void MoveLane(int direction) { lane = Mathf.Clamp(lane + direction, -1, 1); }
    void Jump() { if (cc.isGrounded && !sliding) verticalVelocity = jumpForce; }
    void Slide() { if (!sliding && cc.isGrounded) StartCoroutine(SlideRoutine()); }

    IEnumerator SlideRoutine()
    {
        sliding = true;
        float oldHeight = cc.height; Vector3 oldCenter = cc.center;
        cc.height = 1.2f; cc.center = new Vector3(0f, -0.45f, 0f);
        yield return new WaitForSeconds(0.7f);
        cc.height = oldHeight; cc.center = oldCenter; sliding = false;
    }

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (hit.collider.GetComponent<RunnerObstacle>() != null) RunnerGameDirector.EndRun();
    }

    void OnTriggerEnter(Collider other)
    {
        var boost = other.GetComponent<BoostPickup>();
        if (boost != null) ActivateBoost();
    }
}
