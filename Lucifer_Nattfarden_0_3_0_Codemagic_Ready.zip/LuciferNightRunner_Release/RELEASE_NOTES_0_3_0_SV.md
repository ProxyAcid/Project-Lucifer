# 0.3.0 — spelbar mobil releasekandidat

- Ny startmeny.
- Ny pausmeny.
- Ny game-over-loop med snabb retry.
- Stora touchkontroller för iPhone.
- Swipe-input behållen.
- Sparad high score.
- Souls belönas vid pickups.
- Boost-pickup med tillfällig hastighetsökning.
- Mer varierad procedurgenerering.
- Förbättrat nattljus, material och dimma.
- IAP gjort valfritt så projektet kan testas utan att först installera Unity IAP.
