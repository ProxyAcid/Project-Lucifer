# LUCIFER: NATTFÄRDEN — Playable Release 0.3.0

Detta är en spelbar, mobilfokuserad Unity-build av **Lucifer: Nattfärden**.

## Vad som ingår
- Startmeny och tydlig spel-loop.
- Swipe-styrning + stora iOS-vänliga touchknappar.
- Tre filer, hopp och glid.
- Procedurmässigt genererad nattmiljö och hinder.
- Kex-samlarobjekt och Souls-ekonomi.
- Boost-objekt och hastighetsökning.
- Poäng, bästa poäng och sparad progression via PlayerPrefs.
- Paus, game over och snabb omstart.
- 60 FPS-mål och skärmens sleep timeout avstängd under spel.
- IAP-stöd lämnat som separat integrationssteg så projektet kan öppnas och testas utan Unity IAP-paket.

## Unity-version
Unity 6.0.0f1 enligt projektfilen.

## Viktigt
Detta är en färdig **spelbar releasekandidat**, men inte en färdig App Store-distribution. Innan publicering ska riktiga art assets, ljud, App Store Connect-produkter, privacy policy, metadata, signing och IAP-validering läggas till.
